using Microsoft.AspNetCore.Mvc;
using BusinessLayer.Interface;
using ModelLayer.DTO;
using RepositoryLayer.Entity;
using BusinessLayer.Service;
using Microsoft.AspNetCore.Authorization;
using Microsoft.Extensions.Configuration;
using RabbitMCQProducer.Service;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;

namespace HelloApp.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class HelloAppController : ControllerBase
    {
        private readonly IRegisterHelloBL _registerHelloBL;
        private readonly TokenService _jwtService;
        private readonly RabbitMqProducer _rabbitMQProducer;

        // Constructor with dependencies
        public HelloAppController(IRegisterHelloBL registerHelloBL, TokenService jwtService, RabbitMqProducer rabbitMQProducer)
        {
            _registerHelloBL = registerHelloBL;
            _jwtService = jwtService;
            _rabbitMQProducer = rabbitMQProducer;
        }

        [HttpGet]
        public string Get()
        {
            return _registerHelloBL.registration("value from controller");
        }

        // Login method
        [HttpPost("login")]
        public IActionResult Login(LoginDTO loginDTO)
        {
            try
            {
                bool result = _registerHelloBL.loginuser(loginDTO);

                if (!result)
                {
                    return Unauthorized(new { message = "Invalid credentials" });
                }

                // Generate JWT Token for login
                string token = _jwtService.GenerateToken(loginDTO.Email);

                return Ok(new { token });
            }
            catch (Exception ex)
            {
                return BadRequest(new { message = "An error occurred", error = ex.Message });
            }
        }

        // Register method
        [HttpPost("register")]
        public IActionResult RegisterUser(RegisterDTO newUser)
        {
            try
            {
                UserEntity user = _registerHelloBL.RegisterUser(newUser);
                return Ok(user);
            }
            catch (Exception ex)
            {
                return BadRequest(new { message = "Registration failed", error = ex.Message });
            }
        }

        // Get users method (protected by Authorization)
        [Authorize]
        [HttpGet("users")]
        public IActionResult GetUsers()
        {
            try
            {
                List<AllUsersDTO> users = _registerHelloBL.GetAllUsers();
                return Ok(users);
            }
            catch (Exception ex)
            {
                return BadRequest(new { message = $"Failed to retrieve users", error = ex.Message });
            }
        }


        // Forgot Password method (Step 1: Send reset token via email)
        [HttpPost("forgot-password")]
        public IActionResult ForgotPassword([FromBody] ForgotPasswordRequest request)
        {
            try
            {
                if (string.IsNullOrEmpty(request.Email))
                {
                    return BadRequest(new { message = "Email is required." });
                }

                bool result = _registerHelloBL.ValidateEmail(request.Email);

                Console.WriteLine("result: " +result+"");

                if (result==false)
                {
                    return Ok("Not a valid email");
                }


                // Generate reset token
                var resetToken = _jwtService.GenerateResetToken(request.Email);

                // Create the email payload
                var message = new
                {
                    To = request.Email,
                    Subject = "Reset Your Password",
                    Body = $"Click the link to reset your password: https://localhost:7277/HelloApp/reset-password?token={resetToken}"
                };

                // Publish the message to RabbitMQ for email sending
                _rabbitMQProducer.PublishMessage(message);

                return Ok(new { message = "Password reset email has been sent." });
            }
            catch (Exception ex)
            {
                return BadRequest(new { message = "Error occurred while processing the password reset", error = ex.Message });
            }
        }

        // Reset Password method (Step 2: Validate token and update password)

        [HttpPost("reset-password")]
        public IActionResult ResetPassword([FromBody] ResetPasswordRequest request)
        {
            try
            {
                // Manually get token from query parameters
                string token = HttpContext.Request.Query["token"];

                if (string.IsNullOrEmpty(token) || string.IsNullOrEmpty(request.NewPassword))
                {
                    return BadRequest(new { message = "Token and new password are required." });
                }

                // Validate the token
                var email = _jwtService.ValidateResetToken(token);
                if (email == null)
                {
                    return Unauthorized(new { message = "Invalid or expired token." });
                }

                // Update the password in the database
                bool updateSuccess = _registerHelloBL.UpdateUserPassword(email, request.NewPassword);
                if (!updateSuccess)
                {
                    return BadRequest(new { message = "Failed to update password." });
                }

                return Ok(new { message = "Password changed successfully!" });
            }
            catch (Exception ex)
            {
                return BadRequest(new { message = "Error occurred while resetting password", error = ex.Message });
            }
        }


    }

    // Models for requests , a DTO
    public class ForgotPasswordRequest
    {
        public string Email { get; set; }
    }

    public class ResetPasswordRequest
    {
        //public string Token { get; set; }
        public string NewPassword { get; set; }
    }
}
