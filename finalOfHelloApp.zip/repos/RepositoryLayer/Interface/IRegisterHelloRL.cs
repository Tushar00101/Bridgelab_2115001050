﻿using ModelLayer.DTO;
using RepositoryLayer.Entity;

namespace RepositoryLayer.Interface
{
    public interface IRegisterHelloRL
    {
        public string GetHello(string name);
        public LoginDTO getUserPassword(LoginDTO loginDTO);
        public UserEntity RegisterUser(RegisterDTO newUser);
        public List<AllUsersDTO> GetAllUsers();

        bool ValidateEmail(string email);

        public UserEntity FindByEmail(string email);

        public bool Update(UserEntity user);
    }
}
